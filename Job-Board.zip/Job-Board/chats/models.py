from django.db import models

import uuid
# Create your models here.


class Threads(models.Model):
    thread_id = models.UUIDField(
        max_length=50, primary_key=True, default=uuid.uuid4, unique=True)
    participants = models.ManyToManyField('core.User', blank=True)

    class Meta:
        db_table = 'chat rooms'
        verbose_name_plural = 'Message Rooms'

    def __str__(self):
        return str(self.thread_id)


class Messages(models.Model):
    message_uuid = models.UUIDField(
        max_length=50, primary_key=True, default=uuid.uuid4, unique=True)
    room_id = models.ForeignKey(Threads, on_delete=models.CASCADE)
    sender = models.ForeignKey(
        'core.User', on_delete=models.CASCADE, blank=True, null=True)
    receiver = models.ForeignKey(
        'core.User', related_name='%(class)s_requests_created', on_delete=models.CASCADE, blank=True, null=True)
    content = models.TextField(blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Messages'

    def __str__(self):
        return f'{self.sender} to {self.receiver}'
