from django.urls import path

from chats.views import *

urlpatterns = [
    path('<str:thread>/', chats_view, name='chats_page'),
]