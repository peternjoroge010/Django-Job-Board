from django.contrib import admin

from chats.models import *
# Register your models here.
admin.site.register(Threads)
admin.site.register(Messages)