from chats.models import Threads
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.


@login_required
def chats_view(request, thread):
    chat_room = Threads.objects.get(thread_id=thread)
    user = request.user
    context = {'room': chat_room}
    print(user)
    return render(request, 'chats/chat-room.html', context)
