from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.translation import ugettext_lazy as _

from clients.models import Project


import uuid

def makeUUID():
    return str(uuid())

from .managers import CustomUserManager

class User(AbstractUser):
    username = models.CharField(max_length=200, primary_key=True, unique=True)
    email = models.EmailField(_('email address'), unique=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    last_login = models.DateTimeField(auto_now_add=True, verbose_name='last login')
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = CustomUserManager()

    def __str__(self):
        return self.username

class Location(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    country = models.CharField(max_length=200, blank=True, null=True)
    region = models.CharField(max_length=200, blank=True, null=True)
    regionTime = models.TimeField(blank=True, null=True)

    def __str__(self):
        return self.country

class Education(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    school = models.CharField(max_length=200, blank=True, null=True)
    location = models.ForeignKey(Location, on_delete=models.CASCADE, blank=True, null=True)
    dateStarted = models.DateField(blank=True, null=True)
    dateEnded = models.DateField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    certification = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return str(self.school)




