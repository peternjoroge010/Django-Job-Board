from django import forms
from ckeditor.widgets import CKEditorWidget

from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.forms import widgets

from core.models import *



class CustomUserCreationForm(UserCreationForm):

    class Meta:
        model = User
        fields = ('username','email',)


class CustomUserChangeForm(UserChangeForm):

    class Meta:
        model = User
        fields = ('username','email',)

