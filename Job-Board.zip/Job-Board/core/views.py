from django.shortcuts import get_object_or_404, render,redirect
from django.urls import reverse_lazy
from django.contrib.auth import logout
from django.views.generic.edit import FormView
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm



from core.forms import *
from core.models import *
from clients.models import *
from freelancers.models import *

def register_view(request):
    form = CustomUserCreationForm
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login_page')
    context = {'form':form}
    return render(request, 'core/register.html', context)

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                if UserProfile.objects.filter(userName=user).exists() and ClientProfile.objects.filter(username=user).exists():
                    return redirect('work_page')
                elif ClientProfile.objects.filter(username=user).exists():
                    get_uuid = ClientProfile.objects.filter(username=user).values_list('uuid', flat=True).first()
                    return redirect('clients_page', uuid=get_uuid)
                elif UserProfile.objects.filter(userName=user).exists():
                    return redirect('work_page')
                else:
                    return redirect('welcome_page')
            else:
                messages.error(request, f'Invalid email or password.')
        else:
            messages.error(request, f'Invalid email or password.')

    form = AuthenticationForm()
    context = {'form':form}
    return render(request, 'core/login.html', context)


def logout_view(request):
    try:
        logout(request)
    except KeyError:
        pass
    return redirect('home_page')

@login_required
def welcome_view(request):
    context = {}
    return render(request, 'core/welcome.html', context)


def home(request):
    context = {}
    return render(request, 'core/home.html', context)


