from django.urls import path

from core.views import *

urlpatterns = [
    path('', home, name='home_page'),
    path('login/', login_view, name='login_page'),
    path('logout/', logout_view, name='logout_page'),
    path('register/', register_view, name='register_page'),
    path('welcome/', welcome_view, name='welcome_page'),


]
