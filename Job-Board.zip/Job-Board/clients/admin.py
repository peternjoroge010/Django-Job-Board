from django.contrib import admin
from clients.models import *

from clients.forms import ClientProfileForm, CreateProjectForm
# Register your models here.

class ClientProfileAdmin(admin.ModelAdmin):
    list_display = ('username', 'firstname','lastname', 'country', 'region')
    ordering = ('username',)

class ClientProjectAdmin(admin.ModelAdmin):
    list_display = ('project_id','client','project_title', 'timestamp')
    ordering = ('client', 'project_id', 'timestamp')

admin.site.register(ClientProfile, ClientProfileAdmin)
admin.site.register(Project, ClientProjectAdmin)

