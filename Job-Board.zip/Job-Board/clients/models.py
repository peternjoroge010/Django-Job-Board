from django.db import models
from django.utils.translation import ugettext_lazy as _
from django_countries.fields import CountryField
from ckeditor.fields import RichTextField
import uuid
# Create your models here.
class ClientProfile(models.Model):
    uuid = models.UUIDField(max_length=50, primary_key=True, default=uuid.uuid4, unique=True)
    username = models.OneToOneField('core.User', unique=True, on_delete=models.CASCADE)
    firstname = models.CharField(max_length=200, blank=True, null=True)
    lastname = models.CharField(max_length=200, blank=True, null=True)
    profilephoto = models.ImageField(blank=True, null=True)
    country = CountryField(null=True, blank=True, blank_label='select country')
    region = models.CharField(max_length=200, blank=True, null=True)

    def get_profile_image_filename(self):
        return str(self.profile_image)[str(self.profile_image).index(f'profile_images/'):]
        
    @property
    def imageURL(self):
        try:
            invalid = '() "<>:\/?*'
            for char in invalid:
                url = self.profilephoto.url.replace(char, '')
        except:
            url = ''
        return url


    def __str__(self):
        return str(self.username)



class Project(models.Model):
    experience_choices = (
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Expert', 'Expert'),
    )
    project_choices = (
        ('one time', 'one time'),
        ('short term', 'short term'),
        ('long term', 'long term'),
    )
    rate_choices = (
        ('hourly', 'hourly'),
        ('project', 'project'),
        ('milestone', 'milestone'),
    )
    period_choices = (
        ('less than a month', 'less than a month'),
        ('2-3 months', '2-3 months'),
        ('more than 6 months', 'more than 6 months'),
    )
    project_id = models.UUIDField(max_length=50,primary_key=True, default=uuid.uuid4, unique=True, editable=False)
    client = models.ForeignKey(ClientProfile, on_delete=models.CASCADE, blank=True, null=True)
    project_title = models.CharField(max_length=300, blank=True, null=True)
    rate_type = models.CharField(max_length=200, choices=rate_choices, default="hourly")
    project_type = models.CharField(max_length=200, choices=project_choices, default="one time")
    skills_needed = models.CharField(max_length=10000, blank=True, null=True)
    experience_level = models.CharField(max_length=200, choices=experience_choices, default='Beginner')
    project_period = models.CharField(max_length=200,  choices=period_choices)
    freelancer_pref = models.CharField(max_length=200, blank=True, null=True)
    approx_rate = models.CharField(max_length=200, blank=True, null=True)
    description = RichTextField(blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True, blank=True, null=True)

    def __str__(self):
        return str(self.project_id)
    
    def __unicode__(self):
        return u'%s' % self.project_id
