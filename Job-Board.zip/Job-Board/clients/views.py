from django.shortcuts import render
from django.shortcuts import get_object_or_404, render,redirect
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required


from clients.forms import *
from core.models import *
from freelancers.models import Proposal,UserProfile


# Create your views here.

@login_required
def createClientProfile_view(request, *args, **kwargs):
    """
    :View to create a new client profile
    """
    form = ClientProfileForm
    if request.method == 'POST':
        form = ClientProfileForm(request.POST, request.FILES)
        if form.is_valid():
            new_form = ClientProfile(
                username = request.user,
                firstname = request.POST['firstname'],
                lastname = request.POST['lastname'],
                profilephoto = request.FILES['profilephoto'],
                country = request.POST['country'],
                region = request.POST['region'],
            )
            new_form.save()
            get_uuid = ClientProfile.objects.filter(username=request.user).values_list('uuid', flat=True).first()
            return redirect('clients_page', uuid=get_uuid)

    context = {'form':form}
    return render(request, 'clients/create-client-profile.html', context)

@login_required
def clients_view(request, uuid):
    """
    :This view handles the profile page of clients
    """
    client = ClientProfile.objects.get(uuid=uuid)
    name = ClientProfile.objects.filter(username=request.user).values_list('uuid', flat=True).first()
    project = Project.objects.filter(client=name).order_by('-timestamp')
    proposal = Proposal.objects.filter(job_id__client=client).values_list('job_id', flat=True)
    count=0
    context = {'client':client, 'projects':project, 'proposal':proposal, 'count':count}
    return render(request, 'clients/client-page.html', context)

@login_required
def editclientprofile_view(request, uuid, *args, **kwargs):
    """
    :Allow clients to update their profile
    """
    profile = get_object_or_404(ClientProfile, uuid=uuid)
    form = ClientProfileForm(instance=profile)
    if request.method == 'POST':
        form = ClientProfileForm(request.POST, request.FILES)
        if form.is_valid():
            ClientProfile.objects.filter(uuid=uuid).update(
                username = request.user,
                firstname = request.POST['firstname'],
                lastname = request.POST['lastname'],
                profilephoto = request.FILES['profilephoto'],
                country=request.POST['country'],
                region=request.POST['region'],
            )
            return redirect('clients_page', uuid)

    context = {'profile':profile, 'form':form}
    return render(request, 'clients/edit-client-profile.html', context)

@login_required
def createproject_view(request, uuid, *args, **kwargs):
    """
    :Allow clients to create new project
    """
    client = get_object_or_404(ClientProfile, uuid=uuid)
    form = CreateProjectForm
    name = ClientProfile.objects.get(username=request.user)
    if request.method == 'POST':
        form = CreateProjectForm(request.POST)
        print(request.user, name.username)
        if form.is_valid():
            new_form = Project(
                client = name,
                project_title = request.POST['project_title'],
                rate_type = request.POST['rate_type'],
                project_type = request.POST['project_type'],
                skills_needed = request.POST['skills_needed'],
                experience_level = request.POST['experience_level'],
                project_period = request.POST['project_period'],
                freelancer_pref = request.POST['freelancer_pref'],
                approx_rate = request.POST['approx_rate'],
                description = request.POST['description']
            )
            new_form.save()
            return redirect('clients_page', uuid=uuid)
    context = {'form':form, 'client':client}
    return render(request, 'clients/create-project.html', context)

@login_required
def reviewproposal_view(request, id):
    project = Project.objects.get(project_id=id)
    proposals = Proposal.objects.filter(job_id=id)
    profiles = UserProfile.objects.all()
    get_uuid = ClientProfile.objects.filter(username=request.user).values_list('uuid', flat=True).first()
    context = {'proposals':proposals, 'project':project, 'profiles':profiles, 'client':get_uuid}
    return render(request, 'clients/review-proposal.html', context)

@login_required
def viewfreelancers_view(request, uuid):
    profiles = UserProfile.objects.all()
    get_uuid = ClientProfile.objects.get(uuid=uuid)
    context = {'profiles':profiles, 'client':get_uuid}
    return render(request, 'clients/list-freelancers.html', context)
