from django import forms
from clients.models import ClientProfile
from core.models import Project

from ckeditor.widgets import CKEditorWidget
from django_countries.widgets import CountrySelectWidget

class ClientProfileForm(forms.ModelForm):

    class Meta:
        model = ClientProfile
        fields = ('firstname', 'lastname', 'profilephoto', 'country', 'region')
        widgets = {
            'country':CountrySelectWidget,
        }

class CreateProjectForm(forms.ModelForm):
    description = forms.CharField(widget=CKEditorWidget())
    class Meta:
        model = Project
        fields = ('project_title', 'rate_type', 'project_type', 'skills_needed', 'freelancer_pref', 'experience_level', 'project_period', 'description',)
       
