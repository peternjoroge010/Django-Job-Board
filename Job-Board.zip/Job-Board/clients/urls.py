from django.urls import path

from django.conf import settings
from django.conf.urls.static import static

from clients.views import *

urlpatterns = [
    path('create-profile/', createClientProfile_view, name='clientProfile_page'),
    path('<str:uuid>/', clients_view, name='clients_page'),
    path('<str:uuid>/hire/', viewfreelancers_view, name='viewfreelancers_page'),
    path('<str:uuid>/edit-profile/',editclientprofile_view, name='editclientprofile_page'),
    path('project/<str:id>', reviewproposal_view, name='reviewproposal_page'),
    path('<str:uuid>/create-new-project/', createproject_view, name='createproject_page'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)