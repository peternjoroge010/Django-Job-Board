from django.contrib import admin
from freelancers.models import *

from freelancers.forms import UserProfileForm, ProposalForm
# Register your models here.

class ProfileAdmin(admin.ModelAdmin):
    form = UserProfileForm
    model = UserProfile
    list_display = ('userName', 'firstName', 'lastName', 'country', 'region')
    ordering = ('userName', 'firstName', 'lastName', 'country', 'region')

class ProposalAdmin(admin.ModelAdmin):
    form = ProposalForm
    model = Proposal
    list_display = ('freelancer','Proposal_id','job_id', 'timestamp')
    ordering = ('freelancer', 'job_id', 'timestamp')
    search_fields = ('freelancer',)

admin.site.register(UserProfile, ProfileAdmin)
admin.site.register(Proposal, ProposalAdmin)