from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

from freelancers.models import *
from freelancers.forms import *

from freelancers.filters import ProjectFilter

from clients.models import Project

# Create your views here.


@login_required
def createFreelancerProfile_view(request, *args, **kwargs):
    form = UserProfileForm
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES)
        if form.is_valid():
            new_form = UserProfile(
                userName=request.user,
                firstName=request.POST['firstName'],
                lastName=request.POST['lastName'],
                profilePhoto=request.FILES['profilePhoto'],
                title=request.POST['title'],
                description=request.POST['description'],
                experience=request.POST['experience'],
                availability=request.POST['availability'],
                skillset=request.POST['skillset'],
                country=request.POST['country'],
                region=request.POST['region'],
                hourlyRate=request.POST['hourlyRate'],
            )
            new_form.save()
            return redirect('work_page')

    context = {'form': form}
    return render(request, 'freelancers/create-freelancer-profile.html', context)


@login_required
def profile_view(request, uuid):
    profile = UserProfile.objects.get(uuid=uuid)
    proposals = Proposal.objects.filter(freelancer=request.user).order_by('-timestamp')
    context = {'profile': profile, 'proposals':proposals}
    return render(request, 'freelancers/profile.html', context)


@login_required
def editFreelancerProfile_view(request, uuid, *args, **kwargs):
    profile = get_object_or_404(UserProfile, uuid=uuid)
    form = UserProfileForm(instance=profile)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES)
        if form.is_valid():
            UserProfile.objects.filter(uuid=uuid).update(
                userName=request.user,
                firstName=request.POST['firstName'],
                lastName=request.POST['lastName'],
                profilePhoto=request.FILES['profilePhoto'],
                title=request.POST['title'],
                description=request.POST['description'],
                experience=request.POST['experience'],
                availability=request.POST['availability'],
                skillset=request.POST['skillset'],
                country=request.POST['country'],
                region=request.POST['region'],
                hourlyRate=request.POST['hourlyRate'],
            )
            return redirect('profile_page', uuid)

    context = {'profile': profile, 'form': form}
    return render(request, 'freelancers/edit-freelancer-profile.html', context)


@login_required
def work_view(request):
    jobs = Project.objects.all().order_by('-timestamp')
    myFilter = ProjectFilter(request.GET, queryset=jobs)
    jobs = myFilter.qs
    profile = UserProfile.objects.get(userName=request.user)
    paginated_jobs = Paginator(jobs, 5)
    page_number = request.GET.get('page')
    jobs_obj = paginated_jobs.get_page(page_number)
    context = {'jobs': jobs, 'profile': profile,
               'myFilter': myFilter, 'jobs_obj': jobs_obj}
    return render(request, 'freelancers/findwork.html', context)


@login_required
def viewProject_view(request, project_id):
    project = Project.objects.get(project_id=project_id)
    proposals = Proposal.objects.filter(job_id=project_id)
    profile = UserProfile.objects.get(userName=request.user)

    if Proposal.objects.filter(job_id=project_id, freelancer=request.user).exists():
        check1 = get_object_or_404(Proposal, job_id=project_id, freelancer=request.user)
        context = {'project': project, 'submitted': check1, 'profile':profile, 'proposals':proposals}
        return render(request, 'freelancers/sent-proposal.html', context)   
    else:
        form = ProposalForm
       
        if request.method == 'POST':
            form = ProposalForm(request.POST)
           
            if form.is_valid():
                new_form = Proposal(
                    freelancer=request.user,
                    job_id=project,
                    cover_letter=request.POST['cover_letter'],
                    rate=request.POST['rate']
                )
                new_form.save()
                
                return redirect('work_page')

        context = {'project': project, 'form': form, 'profile':profile, 'proposals':proposals}
    return render(request, 'freelancers/view-project.html', context)

    #else: 'submitted':check1
    #if UserProfile.objects.filter(userName=user).exists() and ClientProfile.objects.filter(username=user).exists():

    #var = Proposal.objects.filter()
    #if Project.objects.get(project_id=project_id).filter(freelancer=request.user).exists():
     #   print(project_id, project.project_id)
    #else:
    #    print()
    
