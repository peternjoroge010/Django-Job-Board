from django.apps import AppConfig


class FreelancersConfig(AppConfig):
    name = 'freelancers'
