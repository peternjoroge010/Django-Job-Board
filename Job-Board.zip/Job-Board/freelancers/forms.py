from django import forms
from django_countries.widgets import CountrySelectWidget
from ckeditor.widgets import CKEditorWidget

from freelancers.models import *

class ProposalForm(forms.ModelForm):
    cover_letter = forms.CharField(widget=CKEditorWidget())
    
    class Meta:
        model = Proposal
        fields = ('rate',)
    
class UserProfileForm(forms.ModelForm):
    
    class Meta:
        model = UserProfile
        fields = ('firstName', 'lastName', 'profilePhoto', 'title','description',
                    'experience', 'availability', 'country', 'skillset',
                    'region', 'hourlyRate'
        )
        widgets = {
            'country':CountrySelectWidget,
            'description': RichTextField()
        }
