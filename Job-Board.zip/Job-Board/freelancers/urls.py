from django.urls import path

from freelancers.views import *

urlpatterns = [
    path('create-profile/', createFreelancerProfile_view, name='createUserProfile_page'),
    path('profile/<str:uuid>/', profile_view, name='profile_page'),
    path('profile/<str:uuid>/edit-profile/',editFreelancerProfile_view, name='editProfile_page'),
    path('find-work/', work_view, name='work_page'),
    path('find-work/<str:project_id>/', viewProject_view, name="project_page"),
]