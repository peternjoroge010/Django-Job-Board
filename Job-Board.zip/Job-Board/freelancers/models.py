from django.db import models
from django_countries.fields import CountryField
from clients.models import Project

from ckeditor.fields import RichTextField

import uuid
# Create your models here.
def get_profile_image_filepath(self):
    return f'profile_images/{"profile_image.png"}'

class UserProfile(models.Model):
    availability_choices = (
        ('always', 'always'),
        ('6 hours', '6 hours'),
        ('3 hours', '3 hours'),
        ('1 hour', '1 hour'),
    )
    experience_choices = (
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Expert', 'Expert'),
    )
    uuid = models.UUIDField(max_length=50, primary_key=True, default=uuid.uuid4, unique=True)
    userName = models.ForeignKey('core.User', on_delete=models.CASCADE, null=True)
    firstName = models.CharField(max_length=200, blank=True, null=True)
    lastName = models.CharField(max_length=200, blank=True, null=True)
    profilePhoto = models.ImageField()
    title = models.CharField(max_length=200, blank=True, null=True)
    description =RichTextField(blank=True, null=True)
    experience = models.CharField(max_length=200, choices=experience_choices, default='Beginner')
    availability = models.CharField(max_length=200, choices=availability_choices, default='always')
    skillset = models.TextField(blank=True, null=True)
    country = CountryField(null=True, blank=True, blank_label='select country')
    region = models.CharField(max_length=200, blank=True, null=True)
    hourlyRate = models.DecimalField(max_digits=10000, decimal_places=2, default=0.00)

    @property
    def imageURL(self):
        try:
            url = self.profilePhoto.url
        except:
            url = ''
        return url
    
    def get_profile_image_filename(self):
        return str(self.profile_image)[str(self.profile_image).index(f'profile_images/'):]

    def __str__(self):
        return str(self.userName)
      

class Proposal(models.Model):
    Proposal_id = models.UUIDField(max_length=50, default=uuid.uuid4, unique=True)
    freelancer = models.ForeignKey('core.User', on_delete=models.CASCADE, null=True, blank=True)
    job_id = models.ForeignKey('clients.Project', on_delete=models.CASCADE, null=True, blank=True)
    cover_letter = RichTextField(blank=True, null=True)
    rate = models.DecimalField(max_digits=10000, decimal_places=2, default=0.00)
    timestamp = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return str(self.Proposal_id)
    
