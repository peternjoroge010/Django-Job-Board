import django_filters

from core.models import *

class ProjectFilter(django_filters.FilterSet):
    class Meta:
        model = Project
        fields = ( 'rate_type', 'experience_level', 'project_period')